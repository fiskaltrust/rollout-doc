# Run this script like: .\CheckFirewall.ps1 FirewallTests.csv

param ($urlsFileName)

function GetResultObject
{
    param (
        [string]$Server,
        [string]$Notes,
        [string]$Purpose
    )

    $props = @{
                From = $env:COMPUTERNAME
                Url = $Server
                Notes = $Notes
                Purpose = $Purpose
            }

    New-Object PsObject -Property $props
}

function TestConnection
{
    param 
    (
        [string]$Server
    )
    $WebResponse = Invoke-WebRequest -UseBasicParsing $Server
    return $WebResponse.StatusCode -eq "200"
}

function FirewallEntry
{
	param (
		[string]$Server,
        [string]$Purpose
	)

	$props= @{
		RemoteUrl = $Server
        Purpose = $Purpose
        
	}

	return New-Object PsObject -Property $props
}

function RunUrlCheck
{

  param (
   [String]$file #This is meant to be a CSV with "Url", and "Purpose" fields. Purpose describes why the url is needed, so that we can reason about things more easily.
  )

    If (!$file) {
        Write-Host "Usage: .\CheckFirewall.ps1 filename.csv"
        return
    }

	$testsToRun = Import-Csv -Path $file

	$urls = @()
	 
	foreach($test in $testsToRun)
	{
		$convertedItem = FirewallEntry -Server $test.Url -Purpose $test.Purpose
		$urls = $urls + $convertedItem
	}

	$results = @()
	foreach ($item in $urls) 
	{
		If(TestConnection -Server $item.RemoteUrl)
		{
			$resultObj = GetResultObject -Server $item.RemoteUrl -Notes 'okay' -Purpose $item.Purpose
		}
		Else
		{
			$resultObj = GetResultObject -Server $item.RemoteUrl -Notes 'Server did not respond' -Purpose $item.Purpose
		}

		$results = $results + $resultObj
	}
    
    $failedItems = $results | ? { $_.Notes -ne "okay" } | measure
    If ($failedItems.Count -gt 0)
    {
  		Write-Host "FAILED!"
		  Write-Host "Number of failures: " + $failedItems.Count
    }
    Else
    {
  		Write-Host "We're all good!"
    }

    foreach($result in $results)
    {
        If($result.Notes -eq "okay")
        {
            $status = "SUCCESS"
        }
        Else
        {
            $status = "FAILURE"
        }

        $statusMessage = "Status: ($status) -- Purpose: " + $result.Purpose
    		Write-Host $statusMessage
    }

	Write-Host "Full Results below: "
	$results | Format-Table -AutoSize
}

RunUrlCheck -file $urlsFileName